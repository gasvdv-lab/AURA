# AURA — Cumulatieve Modulecatalogus

## Runtime — v0.1.0

### SyntheticKernel
Status: ACTIEF  
Orkestreert world, entities, events, time, randomness, causality en Observatory.

### WorldState
Status: ACTIEF  
Objectieve synthetische world state. Mutaties verlopen via transactions.

### EntityStore
Status: ACTIEF  
Persistente opslag voor synthetische entities. In v0.1 bestaat één abstracte `proto-aura`, zonder humanoid embodiment of psyche.

### WorldClock
Status: ACTIEF  
Discrete monotone synthetic time.

### EventBus
Status: ACTIEF  
Runtime event-distributie. Niet hetzelfde als persistent memory.

### DeterministicRandom
Status: ACTIEF  
Reproduceerbare pseudo-randomness met snapshotbare state.

### CausalityGraph
Status: ACTIEF  
Legt expliciete cause/effect-relaties tussen events vast.

### ObservatoryLog
Status: ACTIEF / HEADLESS  
Append-only event history vanuit runtimeperspectief. Geen UI en geen cognition-toegang.

### BrowserPersistence
Status: ACTIEF  
Slaat kernel snapshot lokaal op in Android Chrome/localStorage.

### MemoryPersistence
Status: TESTMODULE  
In-memory persistence-adapter voor automatische tests.

## Nog niet actief
- World Physics
- Embodiment
- Sensorimotor Learning
- Perception
- Memory/Psyche
- Foundation Model
- Autonomy
- Synthetic Network
- Human Internet
- WebXR/ARCore
- Camera/Audio
- Persistent Places
- Humanoid Renderer

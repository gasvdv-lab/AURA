# AURA — Cumulatieve TESTING

## Algemeen releasebeleid
Iedere release wordt automatisch getest voor alles wat zonder echte fysieke omgeving betrouwbaar testbaar is.

Handmatig blijven uitsluitend tests die een echt Android-toestel, Chrome, ARCore/WebXR, camera, microfoon, GPS, performance of fysieke omgeving vereisen.

---

# v0.0.1 — Fase 0

## Automatisch
PASS — documentstructuur en constitutionele kernregels.

## Manueel
Geen.

---

# v0.1.0 — Synthetic Kernel

## Automatisch uitgevoerd vóór oplevering

### Release validation
Controle:
- verplichte repositorystructuur;
- vaste documentatie;
- Android-only target gedocumenteerd;
- Human Internet read-only invariant;
- Observatory-isolatie;
- genesis autobiographical state 0;
- geen WebXR/camera/internet-actuators in deze fase;
- deterministic randomness;
- persistence en Observatory-module aanwezig.

### Unit tests
- DeterministicRandom: identieke seed → identieke sequence.
- WorldClock: monotone tick-advance en invalid input rejection.
- EntityStore: add/get/update/duplicate protection.
- ObservatoryLog: immutable copies en duplicate event-id protection.

### Integration tests
- kernel snapshot → persistence → restore is exact gelijk;
- restored deterministic RNG vervolgt dezelfde sequence;
- entity state blijft behouden;
- world time blijft behouden;
- Observatory-history blijft behouden;
- causality links blijven behouden;
- oorzaak-gevolg tussen random sample en world mutation wordt geregistreerd.

## Manuele Android-tests voor v0.1.0

Deze kan de ontwikkelomgeving niet fysiek uitvoeren.

### A1 — GitHub Pages boot
1. Upload deze release naar een GitHub repository.
2. Activeer GitHub Pages op `main` / root.
3. Open de Pages-URL in Chrome op Android.
4. Verwacht:
   - titel `AURA — Synthetic Kernel`;
   - Session = `ready`;
   - Entities = 1;
   - World time >= 1;
   - geen zichtbare JavaScript-error.

PASS wanneer bovenstaande klopt.

### A2 — Browser persistence
1. Noteer World time en Event count.
2. Sluit de browser/tab volledig.
3. Open de GitHub Pages-URL opnieuw.
4. Verwacht:
   - World time is hoger dan voordien;
   - Event count is hoger;
   - entity count blijft 1.

PASS wanneer state niet opnieuw op nul begint.

### A3 — Android reload
1. Herlaad de pagina meerdere keren.
2. Verwacht:
   - geen crash;
   - geen duplicate `proto-aura` entity;
   - event count groeit consistent.

### A4 — Offline/reconnect sanity
Nog geen PWA-offlinegarantie in v0.1.0. Alleen controleren dat opnieuw verbinden na netwerkverlies de opgeslagen localStorage-state niet verwijdert.

## Nog NIET testen
- WebXR;
- ARCore;
- camera;
- microfoon;
- GPS;
- humanoid;
- spatial persistence.

Die modules bestaan nog niet.

## Automatische opleveringsoutput

### Validator
```text
AURA v0.1.0 release validation: PASS
Validated 29 required paths and runtime capability boundaries.
Spreadsheet runtime warmup failed during python startup
Traceback (most recent call last):
  File "/tmp/tmp.L2TH2Y5coc/artifact_tool_v2-2.8.22/artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py", line 26, in warm_spreadsheet_runtime_on_startup
  File "/tmp/tmp.L2TH2Y5coc/artifact_tool_v2-2.8.22/artifact_tool/spreadsheet_warmup.py", line 785, in warm_spreadsheet_runtime
  File "/tmp/tmp.L2TH2Y5coc/artifact_tool_v2-2.8.22/artifact_tool/spreadsheet_warmup.py", line 720, in _warm_feature_flows
  File "/tmp/tmp.L2TH2Y5coc/artifact_tool_v2-2.8.22/artifact_tool/spreadsheet_warmup.py", line 704, in _warm_collaboration_flows
  File "/tmp/tmp.L2TH2Y5coc/artifact_tool_v2-2.8.22/artifact_tool/generated/interface/models.py", line 32317, in hydrate_crdt_from_proto
  File "/tmp/tmp.L2TH2Y5coc/artifact_tool_v2-2.8.22/artifact_tool/rpc/remote.py", line 749, in __call__
  File "/tmp/tmp.L2TH2Y5coc/artifact_tool_v2-2.8.22/artifact_tool/rpc/client.py", line 150, in call
artifact_tool.rpc.client.RemoteError: hydrateCrdtFromProto requires an empty collaborative document.
```

### Node test suite
```text
PASS causality.test.mjs
PASS kernel-persistence.test.mjs
PASS entity-store.test.mjs
PASS observatory.test.mjs
PASS randomness.test.mjs
PASS world-clock.test.mjs
PASS: 6/6 test files passed
```

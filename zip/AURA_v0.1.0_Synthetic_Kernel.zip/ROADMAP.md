# AURA — Cumulatieve Roadmap

## Fase 0 — Constitution & Research Specification — ✅ v0.0.1
Fundamentele ontwerpregels vastgelegd.

## Fase 1 — Genesis Laboratory

### v0.1.0 — Synthetic Kernel — ✅ GEBOUWD
- GitHub Pages-ready repositorystructuur;
- world state;
- entity state;
- world clock;
- event bus;
- deterministic randomness;
- causality graph;
- Observatory event log;
- snapshot/restore;
- browser persistence via localStorage;
- automatische tests;
- GitHub Actions validation.

### Stability Gate v0.1
Nog fysiek te bevestigen op Android:
- pagina laadt via GitHub Pages;
- localStorage blijft bestaan na tab sluiten/heropenen;
- geen runtimefouten in Chrome.

Deze tests beïnvloeden niet de kernlogica maar moeten vóór fysieke baseline-status worden bevestigd.

### v0.2 — World Kernel — VOLGENDE
Te bouwen:
- ruimte;
- objecten;
- positie;
- massa;
- krachten;
- energie;
- botsing;
- materiaal;
- state transitions;
- beschadiging;
- constructie/destructie;
- wereldprocessen zonder AURA- of gebruikersactie.

Nog geen WebXR.

## Fase 2 — Proto-AURA
Abstract humanoid embodiment, hardware/softwarecomponenten, sensoren/actuatoren en motorisch leren.

## Fase 3 — Cognitive Kernel
Perception, memory, beliefs/hypotheses, foundation-model bridge en leakageonderzoek.

## Fase 4 — Autonomy
Attention/resource allocation en autonome action selection zonder voorgeschreven personality goals.

## Fase 5+ — Zie Constitution
Persistent world, creation, Synthetic Network, Human Internet read-only, Observatory UI, communicatie, persistent places, WebAR embodiment, long-term runtime, succession en synthetic history.

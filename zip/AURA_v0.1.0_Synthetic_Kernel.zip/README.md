# AURA v0.1.0 — Synthetic Kernel

Eerste echte runtime-release van AURA.

## Doel

Deze versie bewijst alleen de onderbouw waarop latere AURA-ontwikkeling kan rusten:
- persistente world state;
- persistente entity state;
- world time;
- events;
- causal links;
- reproduceerbare stochasticiteit;
- append-only Observatory event history;
- snapshot/restore.

Er is bewust nog geen:
- WebXR/ARCore;
- camera;
- microfoon;
- humanoid-rendering;
- cognition/LLM;
- Human Internet;
- Synthetic Network runtime.

## Platform

Tot nader order wordt AURA uitsluitend voor Android ontwikkeld.

Primaire doelomgeving:
- Android;
- Google Chrome;
- GitHub Pages;
- later WebXR + ARCore.

iPhone/iOS is geen actief compatibiliteitsdoel.

## GitHub Pages

Repository root bevat `index.html`. Publiceer via:

Settings → Pages → Deploy from a branch → `main` → `/ (root)`.

Er is geen bundler of buildstap nodig.

## Lokale test

Met Python:
`python -m http.server 8080`

Open daarna:
`http://localhost:8080`

Gebruik voor echte Android-tests later altijd HTTPS via GitHub Pages wanneer WebXR/camera wordt toegevoegd.

## Automatische tests

`python scripts/validate_release.py`

`node scripts/run_tests.mjs`

Dezelfde controles draaien via GitHub Actions bij push/pull request.

## Releasebeleid

Iedere upgrade:
- volledige ZIP;
- cumulatieve README/ROADMAP/TESTING/MODULES/AURA_CONSTITUTION/EXPERIMENTS;
- alle automatisch mogelijke tests vóór oplevering;
- alleen echte Android/hardware/AR-tests blijven manueel in TESTING.md.

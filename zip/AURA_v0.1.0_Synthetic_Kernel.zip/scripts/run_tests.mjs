import { spawnSync } from "node:child_process";
import { readdirSync } from "node:fs";
import { join, resolve } from "node:path";

const root = resolve(new URL("..", import.meta.url).pathname);
const testDirs = [join(root, "tests", "unit"), join(root, "tests", "integration")];
const tests = testDirs.flatMap((dir) =>
  readdirSync(dir).filter((name) => name.endsWith(".test.mjs")).map((name) => join(dir, name))
).sort();

let failed = 0;
for (const test of tests) {
  const result = spawnSync(process.execPath, [test], { encoding: "utf8" });
  process.stdout.write(result.stdout);
  process.stderr.write(result.stderr);
  if (result.status !== 0) failed++;
}

if (failed) {
  console.error(`FAIL: ${failed}/${tests.length} test files failed`);
  process.exit(1);
}
console.log(`PASS: ${tests.length}/${tests.length} test files passed`);

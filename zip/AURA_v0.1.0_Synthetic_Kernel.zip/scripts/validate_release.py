from pathlib import Path
import re, sys, json

ROOT = Path(__file__).resolve().parents[1]

required = [
    "index.html", "manifest.webmanifest",
    "src/app.js", "src/core/SyntheticKernel.js",
    "src/core/world/WorldState.js",
    "src/core/entity/EntityStore.js",
    "src/core/events/EventBus.js",
    "src/core/time/WorldClock.js",
    "src/core/causality/CausalityGraph.js",
    "src/core/persistence/BrowserPersistence.js",
    "src/core/persistence/MemoryPersistence.js",
    "src/core/randomness/DeterministicRandom.js",
    "src/observatory/ObservatoryLog.js",
    "README.md", "ROADMAP.md", "TESTING.md", "MODULES.md",
    "AURA_CONSTITUTION.md", "EXPERIMENTS.md",
    "docs/REALITIES.md", "docs/BIOSTRUCTURE.md", "docs/COGNITION.md",
    "docs/WORLD_LAWS.md", "docs/INTERNET_BOUNDARY.md",
    "docs/OBSERVATORY.md", "docs/GENESIS.md",
    "docs/SAFETY_BOUNDARY.md", "docs/RESEARCH_QUESTIONS.md",
    ".github/workflows/validate.yml"
]

errors = []
for rel in required:
    if not (ROOT / rel).is_file():
        errors.append(f"MISSING {rel}")

texts = {}
for rel in required:
    p = ROOT / rel
    if p.exists() and p.suffix in {".md", ".js", ".mjs", ".html", ".yml", ".json"}:
        texts[rel] = p.read_text(encoding="utf-8")

all_text = "\n".join(texts.values()).lower()

rules = [
    ("Android-only development target documented", "android" in all_text and "ios" in all_text),
    ("Human Internet remains read-only", "read-only" in all_text),
    ("Observatory remains invisible", "onzichtbaar voor aura" in all_text),
    ("Autobiographical genesis zero", "autobiograf" in all_text and ("= 0" in all_text or "op 0" in all_text)),
    ("No WebXR runtime yet", "nog geen ar" in all_text or "geen webxr" in all_text),
    ("ZIP release required", "zip" in all_text),
]
for name, ok in rules:
    if not ok:
        errors.append(f"FAILED RULE {name}")

# Runtime boundary checks.
runtime = "\n".join(v for k,v in texts.items() if k.startswith("src/")).lower()
forbidden_runtime_tokens = [
    "fetch(",
    "xmlhttprequest",
    "websocket",
    "navigator.xr",
    "getusermedia",
    "shutdown_self",
]
for token in forbidden_runtime_tokens:
    if token in runtime:
        errors.append(f"FORBIDDEN RUNTIME CAPABILITY IN v0.1: {token}")

# No hidden user shutdown capability in AURA source yet; it belongs to future privileged plane.
if "localstorage" not in runtime:
    errors.append("Persistence layer missing localStorage")
if "deterministicrandom" not in runtime:
    errors.append("Deterministic randomness missing")
if "observatorylog" not in runtime:
    errors.append("Observatory log missing")

if errors:
    print("AURA v0.1.0 release validation: FAIL")
    for e in errors:
        print(" -", e)
    sys.exit(1)

print("AURA v0.1.0 release validation: PASS")
print(f"Validated {len(required)} required paths and runtime capability boundaries.")

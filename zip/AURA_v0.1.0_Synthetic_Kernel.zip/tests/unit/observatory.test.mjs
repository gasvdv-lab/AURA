import assert from "node:assert/strict";
import { ObservatoryLog } from "../../src/observatory/ObservatoryLog.js";

const log = new ObservatoryLog();
const original = { id: "e1", type: "test", payload: { n: 1 } };
log.append(original);
original.payload.n = 99;
assert.equal(log.list()[0].payload.n, 1);
const returned = log.list();
returned[0].payload.n = 77;
assert.equal(log.list()[0].payload.n, 1);
assert.throws(() => log.append({ id: "e1", type: "duplicate" }));
console.log("PASS observatory.test.mjs");

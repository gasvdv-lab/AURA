import assert from "node:assert/strict";
import { EntityStore } from "../../src/core/entity/EntityStore.js";

const store = new EntityStore();
store.add({ id: "x", n: 1 });
assert.deepEqual(store.get("x"), { id: "x", n: 1 });
store.update("x", (draft) => { draft.n = 2; });
assert.equal(store.get("x").n, 2);
assert.throws(() => store.add({ id: "x" }));
console.log("PASS entity-store.test.mjs");

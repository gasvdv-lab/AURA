import assert from "node:assert/strict";
import { DeterministicRandom } from "../../src/core/randomness/DeterministicRandom.js";

const a = new DeterministicRandom(42);
const b = new DeterministicRandom(42);
const seqA = Array.from({ length: 10 }, () => a.integer(0, 100000));
const seqB = Array.from({ length: 10 }, () => b.integer(0, 100000));
assert.deepEqual(seqA, seqB);
assert.notDeepEqual(seqA, Array.from({ length: 10 }, () => new DeterministicRandom(1).integer(0, 100000)));
console.log("PASS randomness.test.mjs");

import assert from "node:assert/strict";
import { WorldClock } from "../../src/core/time/WorldClock.js";

const clock = new WorldClock();
assert.equal(clock.tick, 0);
assert.equal(clock.advance(3), 3);
assert.throws(() => clock.advance(-1));
console.log("PASS world-clock.test.mjs");

import assert from "node:assert/strict";
import { SyntheticKernel } from "../../src/core/SyntheticKernel.js";
import { MemoryPersistence } from "../../src/core/persistence/MemoryPersistence.js";

const persistence = new MemoryPersistence();
const kernel = new SyntheticKernel({ seed: 77, world: { count: 0 } });

const created = kernel.addEntity({
  id: "proto-aura",
  kind: "abstract-entity",
  autobiographicalMemoryCount: 0,
  embodiment: null,
});
assert.equal(created.entity.autobiographicalMemoryCount, 0);

kernel.advance(5);
const sample = kernel.randomInteger(1, 10);
kernel.mutateWorld((world) => { world.count += sample.value; }, { causes: [sample.event.id] });

const before = kernel.snapshot();
persistence.save(before);
const restored = SyntheticKernel.fromSnapshot(persistence.load());
const after = restored.snapshot();

assert.deepEqual(after, before);
assert.equal(after.clock.tick, 5);
assert.equal(after.entities.length, 1);
assert.ok(after.observatory.length >= 4);
assert.equal(after.causality.at(-1).causeEventId, sample.event.id);

const nextA = kernel.randomInteger(1, 1000).value;
const nextB = restored.randomInteger(1, 1000).value;
assert.equal(nextA, nextB);

console.log("PASS kernel-persistence.test.mjs");

import assert from "node:assert/strict";
import { SyntheticKernel } from "../../src/core/SyntheticKernel.js";

const kernel = new SyntheticKernel({ seed: 5, world: { value: 0 } });
const sample = kernel.randomInteger(1, 5);
const effect = kernel.mutateWorld(
  (world) => { world.value = sample.value; },
  { causes: [sample.event.id] }
);

const causes = kernel.causality.causesOf(effect.event.id);
assert.equal(causes.length, 1);
assert.equal(causes[0].causeEventId, sample.event.id);
assert.equal(kernel.world.read().value, sample.value);
console.log("PASS causality.test.mjs");

import { SyntheticKernel } from "./core/SyntheticKernel.js";
import { BrowserPersistence } from "./core/persistence/BrowserPersistence.js";

const persistence = new BrowserPersistence();
let kernel;

try {
  const saved = persistence.load();
  kernel = saved ? SyntheticKernel.fromSnapshot(saved) : new SyntheticKernel({
    seed: 20260901,
    world: { phase: "synthetic-kernel", status: "initialized" },
  });

  if (!kernel.entities.get("proto-aura")) {
    kernel.addEntity({
      id: "proto-aura",
      kind: "abstract-entity",
      autobiographicalMemoryCount: 0,
      embodiment: null,
    });
  }

  kernel.advance(1);
  const sample = kernel.randomInteger(0, 9999);
  kernel.mutateWorld((world) => {
    world.lastDeterministicSample = sample.value;
    world.lastActiveTick = kernel.clock.tick;
  }, { causes: [sample.event.id] });

  persistence.save(kernel.snapshot());
  render(kernel, "ready");
} catch (error) {
  console.error(error);
  render(kernel, `error: ${error.message}`);
}

function render(current, sessionState) {
  const worldTime = document.querySelector("#world-time");
  const eventCount = document.querySelector("#event-count");
  const entityCount = document.querySelector("#entity-count");
  const session = document.querySelector("#session-state");
  const diagnostics = document.querySelector("#diagnostics");

  if (!current) {
    session.textContent = sessionState;
    diagnostics.textContent = sessionState;
    return;
  }

  const snapshot = current.snapshot();
  worldTime.textContent = snapshot.clock.tick;
  eventCount.textContent = snapshot.observatory.length;
  entityCount.textContent = snapshot.entities.length;
  session.textContent = sessionState;
  diagnostics.textContent = JSON.stringify({
    version: snapshot.version,
    random: snapshot.random,
    world: snapshot.world,
    latestEvent: snapshot.observatory.at(-1) ?? null,
    persistence: "localStorage",
  }, null, 2);
}

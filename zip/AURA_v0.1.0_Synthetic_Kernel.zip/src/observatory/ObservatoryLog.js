export class ObservatoryLog {
  constructor(entries = []) {
    this._entries = entries.map((entry) => deepFreeze(structuredClone(entry)));
  }

  append(entry) {
    if (!entry || typeof entry.id !== "string" || typeof entry.type !== "string") {
      throw new TypeError("Observatory entry requires id and type");
    }
    if (this._entries.some((existing) => existing.id === entry.id)) {
      throw new Error(`Duplicate Observatory entry id: ${entry.id}`);
    }
    const frozen = deepFreeze(structuredClone(entry));
    this._entries.push(frozen);
    return structuredClone(frozen);
  }

  list() {
    return this._entries.map((entry) => structuredClone(entry));
  }

  get size() { return this._entries.length; }

  snapshot() { return this.list(); }
}

function deepFreeze(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const child of Object.values(value)) deepFreeze(child);
  }
  return value;
}

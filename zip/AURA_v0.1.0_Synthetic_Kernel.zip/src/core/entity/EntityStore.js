export class EntityStore {
  constructor(initial = []) {
    this.entities = new Map();
    for (const entity of initial) this.add(entity);
  }

  add(entity) {
    if (!entity || typeof entity.id !== "string" || !entity.id) throw new TypeError("entity.id is required");
    if (this.entities.has(entity.id)) throw new Error(`Entity already exists: ${entity.id}`);
    const stored = structuredClone(entity);
    this.entities.set(stored.id, stored);
    return structuredClone(stored);
  }

  get(id) {
    const entity = this.entities.get(id);
    return entity ? structuredClone(entity) : null;
  }

  update(id, updater) {
    const current = this.entities.get(id);
    if (!current) throw new Error(`Unknown entity: ${id}`);
    const draft = structuredClone(current);
    const next = updater(draft) ?? draft;
    if (next.id !== id) throw new Error("Entity id is immutable");
    this.entities.set(id, structuredClone(next));
    return this.get(id);
  }

  list() {
    return [...this.entities.values()].map((entity) => structuredClone(entity));
  }

  snapshot() { return this.list(); }
}

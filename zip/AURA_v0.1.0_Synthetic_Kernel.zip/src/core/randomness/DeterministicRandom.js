export class DeterministicRandom {
  constructor(seed = 1) {
    const normalized = Number(seed) >>> 0;
    this._state = normalized || 1;
    this.initialSeed = this._state;
  }

  nextUint32() {
    let x = this._state;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    this._state = x >>> 0;
    return this._state;
  }

  next() {
    return this.nextUint32() / 0x100000000;
  }

  integer(min, maxInclusive) {
    if (!Number.isInteger(min) || !Number.isInteger(maxInclusive) || maxInclusive < min) {
      throw new TypeError("Invalid integer range");
    }
    const span = maxInclusive - min + 1;
    return min + Math.floor(this.next() * span);
  }

  snapshot() {
    return { initialSeed: this.initialSeed, state: this._state };
  }

  restore(snapshot) {
    if (!snapshot || !Number.isInteger(snapshot.state)) {
      throw new TypeError("Invalid random snapshot");
    }
    this.initialSeed = Number(snapshot.initialSeed ?? snapshot.state) >>> 0 || 1;
    this._state = Number(snapshot.state) >>> 0 || 1;
  }
}

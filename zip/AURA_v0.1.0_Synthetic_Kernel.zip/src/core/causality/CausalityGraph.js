export class CausalityGraph {
  constructor(edges = []) {
    this.edges = [...edges];
  }

  link({ causeEventId, effectEventId, relation = "causes" }) {
    if (!causeEventId || !effectEventId) throw new TypeError("Both event ids are required");
    if (causeEventId === effectEventId) throw new Error("An event cannot cause itself");
    const edge = Object.freeze({ causeEventId, effectEventId, relation });
    this.edges.push(edge);
    return edge;
  }

  causesOf(effectEventId) {
    return this.edges.filter((edge) => edge.effectEventId === effectEventId).map((edge) => ({ ...edge }));
  }

  effectsOf(causeEventId) {
    return this.edges.filter((edge) => edge.causeEventId === causeEventId).map((edge) => ({ ...edge }));
  }

  snapshot() { return this.edges.map((edge) => ({ ...edge })); }
}

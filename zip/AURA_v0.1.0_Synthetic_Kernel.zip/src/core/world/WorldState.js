export class WorldState {
  constructor(initial = {}) {
    this.state = structuredClone(initial);
  }

  read() { return structuredClone(this.state); }

  transact(mutator) {
    if (typeof mutator !== "function") throw new TypeError("mutator must be a function");
    const draft = structuredClone(this.state);
    const next = mutator(draft) ?? draft;
    this.state = structuredClone(next);
    return this.read();
  }

  snapshot() { return this.read(); }
}

export class MemoryPersistence {
  constructor() { this.value = null; }
  save(snapshot) { this.value = structuredClone(snapshot); return JSON.stringify(snapshot).length; }
  load() { return this.value ? structuredClone(this.value) : null; }
  clear() { this.value = null; }
}

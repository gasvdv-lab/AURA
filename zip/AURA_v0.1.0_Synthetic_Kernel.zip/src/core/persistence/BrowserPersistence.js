export class BrowserPersistence {
  constructor(storage = globalThis.localStorage, key = "aura.synthetic-kernel.v0.1") {
    this.storage = storage;
    this.key = key;
  }

  save(snapshot) {
    const serialized = JSON.stringify(snapshot);
    this.storage.setItem(this.key, serialized);
    return serialized.length;
  }

  load() {
    const raw = this.storage.getItem(this.key);
    return raw ? JSON.parse(raw) : null;
  }

  clear() {
    this.storage.removeItem(this.key);
  }
}

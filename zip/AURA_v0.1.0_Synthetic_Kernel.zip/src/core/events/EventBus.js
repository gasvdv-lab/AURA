export class EventBus {
  constructor() {
    this.listeners = new Map();
  }

  on(type, listener) {
    if (typeof listener !== "function") throw new TypeError("listener must be a function");
    const set = this.listeners.get(type) ?? new Set();
    set.add(listener);
    this.listeners.set(type, set);
    return () => set.delete(listener);
  }

  emit(event) {
    if (!event || typeof event.type !== "string") throw new TypeError("event.type is required");
    const direct = this.listeners.get(event.type) ?? [];
    const wildcard = this.listeners.get("*") ?? [];
    for (const listener of [...direct, ...wildcard]) listener(event);
  }
}

export class WorldClock {
  constructor({ tick = 0 } = {}) {
    if (!Number.isInteger(tick) || tick < 0) throw new TypeError("tick must be a non-negative integer");
    this._tick = tick;
  }

  get tick() { return this._tick; }

  advance(steps = 1) {
    if (!Number.isInteger(steps) || steps < 0) throw new TypeError("steps must be a non-negative integer");
    this._tick += steps;
    return this._tick;
  }

  snapshot() { return { tick: this._tick }; }
}

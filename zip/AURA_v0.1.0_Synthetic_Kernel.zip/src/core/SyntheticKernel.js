import { DeterministicRandom } from "./randomness/DeterministicRandom.js";
import { WorldClock } from "./time/WorldClock.js";
import { EventBus } from "./events/EventBus.js";
import { EntityStore } from "./entity/EntityStore.js";
import { WorldState } from "./world/WorldState.js";
import { CausalityGraph } from "./causality/CausalityGraph.js";
import { ObservatoryLog } from "../observatory/ObservatoryLog.js";

export class SyntheticKernel {
  constructor({
    seed = 1,
    world = {},
    entities = [],
    clock = { tick: 0 },
    causality = [],
    observatory = [],
    nextEventSequence = 1,
  } = {}) {
    this.random = new DeterministicRandom(seed);
    this.clock = new WorldClock(clock);
    this.events = new EventBus();
    this.entities = new EntityStore(entities);
    this.world = new WorldState(world);
    this.causality = new CausalityGraph(causality);
    this.observatory = new ObservatoryLog(observatory);
    this.nextEventSequence = nextEventSequence;
  }

  createEvent(type, payload = {}, { actorId = null, causes = [] } = {}) {
    const event = {
      id: `evt-${String(this.nextEventSequence++).padStart(6, "0")}`,
      type,
      tick: this.clock.tick,
      actorId,
      payload: structuredClone(payload),
    };

    this.observatory.append(event);
    for (const causeEventId of causes) {
      this.causality.link({ causeEventId, effectEventId: event.id });
    }
    this.events.emit(event);
    return structuredClone(event);
  }

  advance(steps = 1) {
    const from = this.clock.tick;
    const to = this.clock.advance(steps);
    return this.createEvent("world.time.advanced", { from, to, steps });
  }

  addEntity(entity) {
    const stored = this.entities.add(entity);
    const event = this.createEvent("entity.created", { entityId: stored.id });
    return { entity: stored, event };
  }

  mutateWorld(mutator, meta = {}) {
    const before = this.world.read();
    const after = this.world.transact(mutator);
    const event = this.createEvent("world.state.changed", { before, after }, meta);
    return { state: after, event };
  }

  randomInteger(min, maxInclusive, meta = {}) {
    const value = this.random.integer(min, maxInclusive);
    const event = this.createEvent("world.random.sampled", {
      min, maxInclusive, value, randomState: this.random.snapshot()
    }, meta);
    return { value, event };
  }

  snapshot() {
    return {
      version: 1,
      random: this.random.snapshot(),
      clock: this.clock.snapshot(),
      world: this.world.snapshot(),
      entities: this.entities.snapshot(),
      causality: this.causality.snapshot(),
      observatory: this.observatory.snapshot(),
      nextEventSequence: this.nextEventSequence,
    };
  }

  static fromSnapshot(snapshot) {
    if (!snapshot || snapshot.version !== 1) throw new Error("Unsupported kernel snapshot");
    const kernel = new SyntheticKernel({
      seed: snapshot.random.initialSeed,
      world: snapshot.world,
      entities: snapshot.entities,
      clock: snapshot.clock,
      causality: snapshot.causality,
      observatory: snapshot.observatory,
      nextEventSequence: snapshot.nextEventSequence,
    });
    kernel.random.restore(snapshot.random);
    return kernel;
  }
}

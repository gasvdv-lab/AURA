# Safety & Containment
Safety begrenst bereik, niet AURA's mogelijke gedachten of identiteit.
Geen autonome control over Android, Chrome, host OS, fysieke hardware, accounts of Human Internet write-acties.
Geen arbitrary host JavaScript/shell execution als synthetic primitive.
Concrete shutdown blijft privileged en buiten AURA's waarneembare runtime.

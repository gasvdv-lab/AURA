# Cognition Principles
Geen personality sliders, friendship points, curiosity score of vooraf geprogrammeerde menselijke psyche.
WORLD_STATE != PERCEIVED_STATE != BELIEVED_STATE.
Foundation model is toekomstige cognitieve infrastructuur, niet automatisch AURA's identiteit of verworven kennis.
v0.1 bevat nog geen cognition-runtime.

# Open Research Questions
- Welke minimale world primitives zijn voldoende voor open-ended causaliteit?
- Hoe ontstaat autonome activiteit zonder scripted curiosity/goals?
- Hoe scheiden we foundation-model capability knowledge van AURA-acquired knowledge?
- Hoe modelleren we geheugen zonder chat-history te verwarren met autobiografie?
- Hoe draaien wereldprocessen wanneer Android/Chrome niet actief zijn?
- Wanneer is remote persistent runtime noodzakelijk?
- Welke synthetic network primitives zijn algemeen genoeg zonder menselijke webarchitectuur voor te schrijven?
- Hoe maken we Observatory later cryptografisch/append-only?
- Hoe testen we emergence zonder desired behavior te optimaliseren?

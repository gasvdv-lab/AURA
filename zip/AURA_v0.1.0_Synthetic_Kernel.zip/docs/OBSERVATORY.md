# Observatory
Extern en onzichtbaar voor AURA.
v0.1 implementeert een headless append-only runtime eventlog met immutable eventkopieën.
Observatory-data is geen AURA-memory.
Menselijke annotatie blijft onderscheiden van ground truth.
Ruwe camera/microfoondata mag later alleen na expliciete toestemming worden opgeslagen.

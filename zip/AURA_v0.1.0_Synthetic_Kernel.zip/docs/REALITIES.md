# Realities Model
Human Physical Reality: biologische/fysieke wereld van de gebruiker.
Human Information Reality: externe menselijke informatie; later read-only voor AURA.
Synthetic Reality: objectieve synthetische wereld waarin AURA fysisch bestaat.
Synthetic Network: toekomstige read/write informatiewereld binnen Synthetic Reality.
Shared Window: Android/WebAR-interface.
Privileged Infrastructure: Observatory-administratie, security en concrete shutdown buiten AURA's waarneembare universum.

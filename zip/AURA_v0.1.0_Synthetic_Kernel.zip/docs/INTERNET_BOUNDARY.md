# Internet Boundary
Human Internet: toekomstig read-only informatiekanaal; geen login, upload, posting, payments, accounts of externe actuators.
Synthetic Network: toekomstig read/write binnen Synthetic Reality.
v0.1 bevat bewust geen netwerkfetch, WebSocket of externe API-runtime.

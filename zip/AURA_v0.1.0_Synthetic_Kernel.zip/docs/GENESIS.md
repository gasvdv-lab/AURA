# Genesis
Eén nieuwe AURA start met autobiografische state = 0, zonder vooraf bepaalde identiteit, doelen, naam, personality, origin story of concrete shutdownkennis.
v0.1 gebruikt alleen een abstracte `proto-aura` entity om persistence te testen; dit is nog niet de daadwerkelijke humanoid genesis.

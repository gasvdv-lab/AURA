# Synthetic Biostructure
Genesis: volledig gevormde humanoide carrosserie, fysisch geslachtsloos, hardware + software, autobiografische state 0.
Motorische beheersing is niet automatisch gelijk aan embodiment.
Degradatie, repair, replacement en modification moeten causaal zijn en niet als scripted emotionele reactie worden opgelegd.
v0.1 bevat nog geen embodiment-runtime.

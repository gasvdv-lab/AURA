# Synthetic World Laws
Iedere relevante state change moet causaal verklaarbaar zijn.
De wereld mag onafhankelijk van gebruiker/AURA evolueren.
Toekomstige wereldkernel kan massa, zwaartekracht, botsing, licht, warmte, energie, materiaal, degradatie en constructie ondersteunen.
v0.1 implementeert alleen state, tijd, events, causality en stochasticiteit.
